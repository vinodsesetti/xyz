from django.apps import AppConfig


class MdgeappConfig(AppConfig):
    name = 'MDGEapp'
